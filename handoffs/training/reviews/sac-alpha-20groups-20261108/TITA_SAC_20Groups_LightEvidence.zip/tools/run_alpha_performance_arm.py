#!/usr/bin/env python3
"""固定128环境的配对性能诊断单臂；不代表控制提升。"""
import argparse, ast, fcntl, hashlib, importlib.util, inspect, json, os
from pathlib import Path
import signal, subprocess, sys, time, traceback, shutil
from dataclasses import asdict
sys.dont_write_bytecode = True
BEGIN_EPOCH = time.time()
BEGIN_MONO = time.perf_counter()
R1_SHA = "46f4c8d0f3013ab95ca51db90babcbf9fcd53f259432abbf6cbf0e7a49153c9a"
PLAN = "SAC-ALPHA-PAIRED-PERFORMANCE-20261108"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path,value):
    path=Path(path); temp=path.with_suffix(path.suffix+".tmp")
    with temp.open("w") as f:
        json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(temp,path)

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module; spec.loader.exec_module(module)
    return module

def main():
    p=argparse.ArgumentParser()
    for flag in ("root","study-root","r1-trainer","r2-tools","plan-parameters","output-dir","lock-file"):
        p.add_argument("--"+flag,type=Path,required=True)
    p.add_argument("--seed",type=int,choices=range(10),required=True)
    p.add_argument("--pair-position",type=int,choices=[1,2],required=True)
    p.add_argument("--variant",choices=["baseline","tensor"],required=True)
    p.add_argument("--num-envs",type=int,choices=[128],default=128)
    p.add_argument("--expected-initial-fingerprints",type=Path)
    p.add_argument("--max-seconds",type=float,default=140)
    p.add_argument("--hard-deadline-epoch",type=float,required=True)
    import tensordict,h5py
    from isaaclab.app import AppLauncher
    AppLauncher.add_app_launcher_args(p)
    args=p.parse_args()
    assert 0<args.max_seconds<=150
    assert (args.expected_initial_fingerprints is not None)==(args.pair_position==2)
    for name in ("root","study_root","output_dir","r2_tools","r1_trainer"):
        setattr(args,name,getattr(args,name).resolve())
    assert not args.output_dir.is_relative_to(args.study_root)
    assert not args.output_dir.is_relative_to(args.r2_tools.parent)
    relative_output=args.output_dir.relative_to(args.root)
    assert relative_output.parts[0].startswith("sac-alpha-pilot-"),relative_output
    assert len(relative_output.parts)>=2,relative_output
    assert sha(args.r1_trainer)==R1_SHA
    args.output_dir.mkdir(parents=True,exist_ok=False)
    deadline=min(BEGIN_EPOCH+args.max_seconds,args.hard_deadline_epoch)
    assert time.time()<deadline-15
    args.arm="R20"; args.stage="alpha_tensor_compatibility"
    args.learner_device="cuda:0"; args._env=None
    args.warmup_iterations=0
    target_iterations=64
    stop={"requested":False}
    signal.signal(signal.SIGTERM,lambda *_:stop.update(requested=True))
    signal.signal(signal.SIGINT,lambda *_:stop.update(requested=True))
    sys.path.insert(0,str(args.r2_tools));sys.path.insert(0,str(args.r1_trainer.parent))
    from linux_common import prepare_args
    args=prepare_args(args)
    lock=args.lock_file.open("a")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    app=None;monitor=None;gpu_file=None;trainer=None
    summary=dict(plan_id=PLAN,status="starting",num_envs=args.num_envs,seed=args.seed,pair_position=args.pair_position,
        warmup_transitions=0,measurement_target_transitions=65536,
        measurement_target_critic_updates=1024,deadline_epoch=deadline,
        process_budget_includes_startup=True,performance_diagnostic_only=True,variant=args.variant,policy_evaluation_performed=False,
        timing_semantics="Host wall times include native item/cpu synchronization within phases; residual_cuda_wait_s is only additional end-of-round synchronize, not total synchronization.")
    write(args.output_dir/"summary.json",summary)
    try:
        gpu_file=(args.output_dir/"gpu-1s.csv").open("w")
        monitor=subprocess.Popen(["nvidia-smi",
            "--query-gpu=timestamp,index,utilization.gpu,utilization.memory,memory.used,memory.total,power.draw,clocks.sm,temperature.gpu",
            "--format=csv","-l","1"],stdout=gpu_file,stderr=subprocess.STDOUT)
        base=load_module("bench_r1_base",args.r1_trainer)
        base.install_paths(args.study_root)
        app=AppLauncher(args).app
        import torch
        import r2_extension as extension
        from checkpoint import MODULE_NAMES
        torch.set_num_threads(4)
        torch.backends.cuda.matmul.allow_tf32=False
        torch.backends.cudnn.allow_tf32=False
        source=inspect.getsource(base.make_trainer)
        def once(old,new):
            nonlocal source
            assert source.count(old)==1,(old,source.count(old))
            source=source.replace(old,new,1)
        once("make_sac_cfg('isaac_flat', 16, 0, args.device or 'cuda:0')",
             "make_sac_cfg('isaac_flat', args.num_envs, args.seed, args.device or 'cuda:0')")
        once("cfg.commands.base_velocity.rel_standing_envs = .02 if args.arm == 'S0' else .20",
             "cfg = configure(cfg, 'R20')")
        once("required, seed=0,", "required, seed=args.seed,")
        once("warmup_iterations=128","warmup_iterations=args.warmup_iterations")
        once("hooks = TitaSacHooks(env, False)","hooks = R2Hooks(env, False)")
        ast.parse(source)
        namespace=dict(base.__dict__)
        namespace.update(PLAN_ID=PLAN,configure=extension.configure,R2Hooks=extension.R2Hooks)
        exec(compile(source,"<isolated-benchmark-constructor>","exec"),namespace)
        (args.output_dir/"effective_make_trainer.py").write_text(source)
        trainer,hooks=namespace["make_trainer"](args)
        extension.install_entropy(trainer)
        import runner
        if args.variant=="tensor":
            assert runner.current_alpha_tensor(trainer.temperature).device == trainer.temperature.log_alpha.device
        else:
            assert not hasattr(runner,"current_alpha_tensor")
        actual_optimizer_steps={key:0 for key in trainer.optimizers}
        for key,optimizer in trainer.optimizers.items():
            original_step=optimizer.step
            def counted_step(*a,_key=key,_original=original_step,**kw):
                result=_original(*a,**kw)
                actual_optimizer_steps[_key]+=1
                return result
            optimizer.step=counted_step
        baseline=json.loads(args.plan_parameters.read_text())["phase_b"]["common_base_config"]
        actual=json.loads(json.dumps(asdict(trainer.config)))
        expected=json.loads(json.dumps(baseline))
        expected["seed"]=args.seed
        expected["collection"]["num_envs"]=args.num_envs
        expected["collection"]["warmup_iterations"]=args.warmup_iterations
        for key in ("seed","mode","task","algorithm","network","collection","environment"):
            assert actual[key]==expected[key],key
        assert trainer.config.name==PLAN and trainer.config.device=="cuda:0"
        initial=dict(networks=base.fingerprint({n:getattr(trainer,n).state_dict() for n in MODULE_NAMES}),
            optimizers=base.fingerprint({n:o.state_dict() for n,o in trainer.optimizers.items()}),
            normalizers=base.fingerprint(trainer.normalizers.export_statistics()),
            empty_replay=trainer.buffer.size==0)
        write(args.output_dir/"initial_fingerprints.json",initial)
        if args.expected_initial_fingerprints:
            assert initial==json.loads(args.expected_initial_fingerprints.read_text())
        write(args.output_dir/"reward_contract_tests.json",hooks.contract_report)
        sources=list(args.study_root.rglob("*.py"))+[args.r1_trainer,Path(extension.__file__),Path(__file__).resolve()]
        hashes={str(path):sha(path) for path in sources}
        write(args.output_dir/"source_hashes.json",hashes)
        timings={}
        def instrument(name,key):
            original=getattr(trainer,name)
            def wrapped(*a,**kw):
                begin=time.perf_counter()
                try:return original(*a,**kw)
                finally:timings[key]=timings.get(key,0.)+time.perf_counter()-begin
            setattr(trainer,name,wrapped)
        instrument("collect_steps","collect_s")
        instrument("learn_from_replay","learn_s")
        instrument("auxiliary_update","auxiliary_s")
        torch.cuda.synchronize()
        summary.update(status="running",startup_seconds=time.perf_counter()-BEGIN_MONO,
            collection_start_epoch=time.time(),initial_fingerprints=initial)
        write(args.output_dir/"summary.json",summary)
        with (args.output_dir/"iterations.jsonl").open("w") as details,(args.output_dir/"timings.jsonl").open("w") as timing_file:
            while trainer.counters.iterations<target_iterations:
                if stop["requested"] or time.time()>=deadline-10:break
                if shutil.disk_usage(args.output_dir).free<10*1024**3:
                    summary["stop_reason"]="disk_below_10GiB";break
                timings.clear();begin=time.perf_counter()
                phase="warmup" if trainer.counters.iterations<args.warmup_iterations else "measurement"
                mark=time.perf_counter()
                for path,expected_hash in hashes.items():assert sha(path)==expected_hash,path
                timings["source_hash_s"]=time.perf_counter()-mark
                log=trainer.train(1)[0]
                mark=time.perf_counter();torch.cuda.synchronize()
                timings["residual_cuda_wait_s"]=time.perf_counter()-mark
                mark=time.perf_counter();base.check_finite(trainer)
                c=trainer.counters
                updates=c.iterations*16
                assert c.transitions==c.iterations*args.num_envs*8
                assert c.env_steps==c.iterations*8
                assert c.critic_updates==c.alpha_updates==c.target_updates==updates
                assert c.actor_updates==updates//2
                assert c.auxiliary_updates+c.auxiliary_skipped==updates
                timings["finite_and_count_checks_s"]=time.perf_counter()-mark
                mark=time.perf_counter()
                log["r2_diagnostics"]=hooks.drain()
                log["r2_diagnostics"]["scope"]=f"8 steps x {args.num_envs} environments; pre-reset"
                log["action_entropy"]=extension.entropy_report(trainer)
                from runner import features_from_history
                with torch.no_grad():
                    features=features_from_history(trainer.encoder,trainer.normalizers,trainer.observation.policy_history.to(trainer.device))
                    mean,log_std=trainer.actor.distribution_parameters(features)
                    log["exploration"]=dict(internal_std_mean=float(log_std.exp().mean()),
                        internal_std_min=float(log_std.exp().min()),internal_std_max=float(log_std.exp().max()),
                        mean_abs_tanh_center=float(mean.tanh().abs().mean()))
                log["episode_reward_components"]={k:float(v) for k,v in hooks.last_episode_log.items()
                    if isinstance(v,(int,float)) or isinstance(v,torch.Tensor) and v.numel()==1}
                timings["diagnostics_s"]=time.perf_counter()-mark
                mark=time.perf_counter();encoded=json.dumps(log,allow_nan=False)
                timings["serialization_s"]=time.perf_counter()-mark
                mark=time.perf_counter();details.write(encoded+"\n");details.flush()
                timings["detail_write_s"]=time.perf_counter()-mark
                row=dict(phase=phase,iteration=c.iterations,epoch=time.time(),transitions=c.transitions,
                    critic_updates=c.critic_updates,iteration_wall_s=time.perf_counter()-begin,**timings)
                timing_file.write(json.dumps(row,allow_nan=False)+"\n");timing_file.flush()
                summary.update(counters=asdict(c),completed_measurement_transitions=c.transitions,
                    last_progress_epoch=time.time(),elapsed_seconds=time.perf_counter()-BEGIN_MONO)
                write(args.output_dir/"summary.json",summary)
        complete=trainer.counters.iterations==target_iterations
        if complete:
            c=trainer.counters
            assert c.transitions==65536 and c.critic_updates==1024 and c.actor_updates==512
            assert c.alpha_updates==1024 and c.target_updates==1024
            assert actual_optimizer_steps["critic"]==1024
            assert actual_optimizer_steps["actor"]==512
            assert actual_optimizer_steps["alpha"]==1024
            assert actual_optimizer_steps["auxiliary"]==c.auxiliary_updates
            assert c.auxiliary_updates+c.auxiliary_skipped==1024
        for path,expected_hash in hashes.items(): assert sha(path)==expected_hash,path
        summary["actual_optimizer_steps"]=actual_optimizer_steps
        summary["final_fingerprints"]={
            "networks":base.fingerprint({n:getattr(trainer,n).state_dict() for n in MODULE_NAMES}),
            "optimizers":base.fingerprint({n:o.state_dict() for n,o in trainer.optimizers.items()})}
        if complete:
            assert summary["final_fingerprints"]["networks"]!=initial["networks"]
            summary["final_model"]=base.validated_save(trainer,args.output_dir,"model_only.pt",False)
        summary.update(status="completed" if complete else "partial_budget",completed_target=complete,
            counters=asdict(trainer.counters),completed_measurement_transitions=trainer.counters.transitions,
            elapsed_seconds=time.perf_counter()-BEGIN_MONO,
            torch_peak_allocated_bytes=torch.cuda.max_memory_allocated(),
            torch_peak_reserved_bytes=torch.cuda.max_memory_reserved(),
            timing_note="Iteration timing excludes its timing-file and atomic-summary writes; overall elapsed includes them. Native synchronization within phases remains included.")
        write(args.output_dir/"summary.json",summary)
        return 0
    except BaseException as exc:
        summary.update(status="failed",error_type=type(exc).__name__,error=str(exc),
            traceback=traceback.format_exc(),elapsed_seconds=time.perf_counter()-BEGIN_MONO,
            counters=asdict(trainer.counters) if trainer else None)
        write(args.output_dir/"summary.json",summary)
        return 1
    finally:
        if monitor:
            monitor.terminate()
            try:monitor.wait(timeout=3)
            except subprocess.TimeoutExpired:monitor.kill();monitor.wait()
        if gpu_file:gpu_file.close()
        if args._env is not None:args._env.close()
        if app is not None:app.close()
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()

if __name__=="__main__":
    sys.exit(main())



