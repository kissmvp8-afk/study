#!/usr/bin/env python3
"""仅后处理本次20组队列；不训练，不修改模型，不混入先前单次结果。"""
import argparse,hashlib,json,math,statistics
from pathlib import Path
T95={1:12.706,2:4.303,3:3.182,4:2.776,5:2.571,6:2.447,7:2.365,8:2.306,9:2.262}
METRICS={"learn_s":"学习耗时","iteration_wall_s":"逐轮总耗时（不含轮外summary写入）","process_wall_s":"完整进程耗时（含启动/关闭）"}
def number(v):
 if isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v) or v<0:raise ValueError("invalid duration: "+repr(v))
 return float(v)
def paired_stats(rows):
 n=len(rows)
 if not n:return dict(n=0,baseline_mean_s=None,tensor_mean_s=None,mean_difference_s=None,median_difference_s=None,sd_difference_s=None,ci95_mean_difference_s=None,reason="no complete pairs")
 b=[number(x[0]) for x in rows];t=[number(x[1]) for x in rows];d=[y-x for x,y in zip(b,t)]
 mean=statistics.mean(d);sd=statistics.stdev(d) if n>=2 else None
 ci=None;crit=None
 if n>=2:
  crit=T95[n-1];half=crit*sd/math.sqrt(n);ci=[mean-half,mean+half]
 return dict(n=n,baseline_mean_s=statistics.mean(b),tensor_mean_s=statistics.mean(t),
  mean_difference_s=mean,median_difference_s=statistics.median(d),sd_difference_s=sd,
  differences_s=d,ci95_mean_difference_s=ci,t_critical=crit,df=n-1,
  all_differences_zero=all(x==0 for x in d),zero_sample_variance=sd==0 if sd is not None else None,
  relative_mean_difference=mean/statistics.mean(b) if statistics.mean(b)!=0 else None,
  ci_interpretation="描述性配对t区间，依赖独立配对与差值分布假设；顺序/温度/缓存混杂仍可能存在。零样本方差不证明总体无不确定性。" if ci else "少于两对，不计算t区间。")
def summarize(queue):
 pairs=queue.get("pairs",[]);assert len(pairs)<=10
 seen=set();included=[];excluded=[]
 for pair in pairs:
  seed=pair["seed"];assert seed in range(10) and seed not in seen;seen.add(seed)
  expected=["baseline","tensor"] if seed%2==0 else ["tensor","baseline"]
  assert pair["order"]==expected
  ok=pair.get("complete") is True and pair.get("initial_fingerprints_match") is True
  arms=pair.get("arms",{})
  ok=ok and all(arms.get(v,{}).get("complete") is True for v in expected)
  if ok:
   for v in expected:
    summary=arms[v]["summary"];c=summary["counters"]
    assert summary["status"]=="completed"
    assert c["iterations"]==64 and c["transitions"]==65536
    assert c["critic_updates"]==c["alpha_updates"]==c["target_updates"]==1024 and c["actor_updates"]==512
   assert arms["baseline"]["summary"]["initial_fingerprints"]==arms["tensor"]["summary"]["initial_fingerprints"]
   included.append(pair)
  else:excluded.append(dict(seed=seed,reason="incomplete or unpaired initialization",arms={v:{"complete":arms.get(v,{}).get("complete",False),"error":arms.get(v,{}).get("error")} for v in expected}))
 def collect(subset,metric):
  def value(arm):return arm["process_wall_s"] if metric=="process_wall_s" else arm["timing"][metric]["sum"]
  return paired_stats([(value(p["arms"]["baseline"]),value(p["arms"]["tensor"])) for p in subset])
 metrics={m:collect(included,m) for m in METRICS}
 strata={order:{"seeds":[p["seed"] for p in included if p["order"][0]==order],
  "metrics":{m:collect([p for p in included if p["order"][0]==order],m) for m in METRICS}} for order in ("baseline","tensor")}
 arms=[arm for p in pairs for arm in p.get("arms",{}).values()]
 return dict(queue_status=queue.get("status"),requested_groups=20,requested_pairs=10,
  groups_attempted=sum(bool(a.get("attempted")) for a in arms),groups_complete=sum(a.get("complete") is True for a in arms),
  attempted_groups_not_complete=sum(bool(a.get("attempted")) and a.get("complete") is not True for a in arms),
  groups_not_attempted=20-sum(bool(a.get("attempted")) for a in arms),
  pairs_included=len(included),pairs_not_included=10-len(included),included_seeds=[p["seed"] for p in included],
  excluded_pairs=excluded,missing_seeds=sorted(set(range(10))-seen),
  metrics=metrics,order_strata=strata,final_fingerprints_equal_count=sum(p.get("final_fingerprints_equal") is True for p in included),
  difference_convention="tensor minus baseline; negative means tensor faster",
  previous_single_pair_included=False,control_evaluation={"status":"not_integrated_schema_pending"},
  caveats=["仅同初始化且完整预算配对参与时间统计；失败与缺失单独报告。",
   "交替顺序只减轻顺序混杂，不能消除GPU温度、时钟、缓存与时间漂移。",
   "学习、逐轮、完整进程耗时是不同指标，不可混为训练质量。",
   "速度变化不代表控制改善；数学等价也不保证GPU仿真轨迹逐位一致。"])
def chinese(r):
 lines=["SAC温度迁移：20组配对观测","完成训练组：%d/20；有效配对：%d/10；尝试后未完成：%d；未尝试：%d。"%(r["groups_complete"],r["pairs_included"],r["attempted_groups_not_complete"],r["groups_not_attempted"]),
 "差值=tensor−baseline，负数表示迁移版更快。先前单次试验未纳入。"]
 for key,label in METRICS.items():
  s=r["metrics"][key]
  if not s["n"]:lines.append(label+"：无有效配对。");continue
  text="%s：基线均值%.6fs，迁移均值%.6fs；配对差均值%+.6fs，中位数%+.6fs（n=%d）。"%(label,s["baseline_mean_s"],s["tensor_mean_s"],s["mean_difference_s"],s["median_difference_s"],s["n"])
  ci=s["ci95_mean_difference_s"]
  text+=(" 差值均值95%% t区间[%+.6f,%+.6f]s。"%tuple(ci)) if ci else " 配对不足，不报t区间。"
  if s.get("all_differences_zero"):text+=" 所有观测差值均为0；样本标准差为0，不等于总体差异已被证明为0。"
  elif s.get("zero_sample_variance"):text+=" 样本差值标准差为0，退化区间不代表没有总体不确定性。"
  elif ci and ci[0]<=0<=ci[1]:text+=" 区间覆盖0，本批未提供方向明确的耗时差证据。"
  elif ci:text+=" 本批区间不覆盖0，但不能单凭此排除硬件与顺序混杂或宣称普遍改进。"
  lines.append(text)
 for first,sub in r["order_strata"].items():
  s=sub["metrics"]["learn_s"];lines.append("%s先运行：n=%d，学习耗时配对均差=%s。"%(first,s["n"],"无数据" if not s["n"] else "%+.6fs"%s["mean_difference_s"]))
 lines.append("控制评价：尚未接入评价schema，不能据训练耗时或奖励宣称控制改善。")
 lines.extend(r["caveats"]);return "\n".join(lines)+"\n"

def summarize_evaluation(evaluation):
 pairs=evaluation.get("pairs",[]);assert len(pairs)<=10
 seen=set();out=dict(status=evaluation.get("status"),requested_groups=20,groups_attempted=0,
  groups_complete=0,attempted_groups_not_complete=0,groups_not_attempted=20,
  versions={},pairs=[],missing_metrics=[],initial_states_equal_count=0,
  initial_states_compared_count=0,step_logs_identical_count=0,step_logs_compared_count=0)
 for v in ("baseline","tensor"):
  out["versions"][v]=dict(complete=0,full_600_steps=0,early_or_short=0,gate_pass=0,
   gate_fail=0,gate_missing=0,freeze_verified=0,stages={})
 for p in pairs:
  seed=p["seed"];assert seed in range(10) and seed not in seen;seen.add(seed)
  assert p["evaluation_seed"]==101+seed%3
  row=dict(seed=seed,evaluation_seed=p["evaluation_seed"],arms={},stage_differences={})
  for key,counter,total in (("initial_states_equal","initial_states_equal_count","initial_states_compared_count"),
    ("step_logs_identical","step_logs_identical_count","step_logs_compared_count")):
   if isinstance(p.get(key),bool):
    out[total]+=1;out[counter]+=int(p[key]);row[key]=p[key]
   else:row[key]=None
  for v in ("baseline","tensor"):
   a=p.get("arms",{}).get(v,{});s=a.get("summary") or {};complete=a.get("complete") is True
   out["groups_attempted"]+=int(bool(a.get("attempted")))
   out["groups_complete"]+=int(complete)
   out["attempted_groups_not_complete"]+=int(bool(a.get("attempted")) and not complete)
   version=out["versions"][v];version["complete"]+=int(complete)
   steps=s.get("steps");full=complete and steps==600
   version["full_600_steps"]+=int(full)
   version["early_or_short"]+=int(complete and isinstance(steps,int) and steps<600)
   gate=s.get("development_gate_pass")
   if complete:version["gate_pass" if gate is True else "gate_fail" if gate is False else "gate_missing"]+=1
   frozen=all(s.get(k) is True for k in ("frozen_state_unchanged","checkpoint_unchanged","normalizers_unchanged"))
   version["freeze_verified"]+=int(complete and frozen)
   arm=dict(complete=complete,steps=steps,full_600_steps=full,gate_pass=gate,
    frozen_verified=frozen,true_terminations=s.get("true_terminations"),timeouts=s.get("timeouts"),
    error=a.get("error"),vx_mae={})
   stages=s.get("stage_metrics") or []
   assert isinstance(stages,list)
   for stage in ("forward","reverse"):
    found=[x for x in stages if x.get("stage")==stage];assert len(found)<=1
    value=found[0].get("vx_mae") if found else None
    if value is not None:value=number(value)
    arm["vx_mae"][stage]=value
    if value is None:out["missing_metrics"].append(dict(seed=seed,variant=v,stage=stage,reason="missing_or_unreached_stage"))
   row["arms"][v]=arm
  for stage in ("forward","reverse"):
   b=row["arms"]["baseline"];t=row["arms"]["tensor"];bv=b["vx_mae"][stage];tv=t["vx_mae"][stage]
   eligible=b["complete"] and t["complete"] and bv is not None and tv is not None
   row["stage_differences"][stage]=dict(tensor_minus_baseline=None if not eligible else tv-bv,
    both_full_600_steps=b["full_600_steps"] and t["full_600_steps"],
    both_freeze_verified=b["frozen_verified"] and t["frozen_verified"])
  out["pairs"].append(row)
 out["groups_not_attempted"]=20-out["groups_attempted"]
 out["groups_not_complete"]=20-out["groups_complete"]
 for v in ("baseline","tensor"):
  for stage in ("forward","reverse"):
   arms=[p["arms"][v] for p in out["pairs"]]
   available=[a["vx_mae"][stage] for a in arms if a["complete"] and a["vx_mae"][stage] is not None]
   full=[a["vx_mae"][stage] for a in arms if a["complete"] and a["full_600_steps"] and a["frozen_verified"] and a["vx_mae"][stage] is not None]
   out["versions"][v]["stages"][stage]=dict(available_complete_n=len(available),
    available_complete_mean=None if not available else statistics.mean(available),
    full_600_frozen_n=len(full),full_600_frozen_mean=None if not full else statistics.mean(full))
 out["interpretation"]="评价完成不等于600步完成或门槛通过。阶段可用样本均值可能含早停样本；完整600步且冻结验证通过的均值单列。缺失阶段不填0。"
 return out

def chinese_evaluation(e):
 lines=["","冻结控制评价：完成%d/20；尝试后未完成%d；未尝试%d。"%(e["groups_complete"],e["attempted_groups_not_complete"],e["groups_not_attempted"])]
 for v,s in e["versions"].items():
  lines.append("%s：评价完成%d，完整600步%d，提前结束/不足600步%d；门槛通过%d、失败%d、未知%d；冻结检查全通过%d。"%(v,s["complete"],s["full_600_steps"],s["early_or_short"],s["gate_pass"],s["gate_fail"],s["gate_missing"],s["freeze_verified"]))
  for stage,x in s["stages"].items():
   lines.append("  %s vx MAE：可用完成评价均值=%s（n=%d）；完整600步且冻结通过均值=%s（n=%d）。"%(stage,str(x["available_complete_mean"]),x["available_complete_n"],str(x["full_600_frozen_mean"]),x["full_600_frozen_n"]))
 lines.append("初态相同%d/%d个已比较配对；逐步日志相同%d/%d个已比较配对。"%(e["initial_states_equal_count"],e["initial_states_compared_count"],e["step_logs_identical_count"],e["step_logs_compared_count"]))
 lines.append("缺失或未到达阶段指标%d项，逐对MAE差值及缺失位置见statistics.json。"%len(e["missing_metrics"]))
 lines.append(e["interpretation"]);return "\n".join(lines)+"\n"

def main():
 p=argparse.ArgumentParser();p.add_argument("--queue-summary",type=Path,required=True);p.add_argument("--output-dir",type=Path,required=True);p.add_argument("--evaluation-summary",type=Path);a=p.parse_args()
 raw=a.queue_summary.read_bytes();result=summarize(json.loads(raw));result["input_sha256"]=hashlib.sha256(raw).hexdigest()
 if a.evaluation_summary:
  evaluation_raw=a.evaluation_summary.read_bytes()
  result["control_evaluation"]=summarize_evaluation(json.loads(evaluation_raw))
  result["evaluation_input_sha256"]=hashlib.sha256(evaluation_raw).hexdigest()
 a.output_dir.mkdir(parents=True,exist_ok=False)
 (a.output_dir/"statistics.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
 report=chinese(result)
 if a.evaluation_summary:
  report=report.replace("控制评价：尚未接入评价schema，不能据训练耗时或奖励宣称控制改善。","控制评价：详见下方独立冻结评价，不以训练耗时替代。")
  report+=chinese_evaluation(result["control_evaluation"])
 (a.output_dir/"report_zh.txt").write_text(report)
if __name__=="__main__":main()

