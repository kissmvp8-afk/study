#!/usr/bin/env python3
"""单次基线/迁移配对；顺序执行，不作控制质量结论。"""
import argparse,ast,copy,shutil,hashlib,json,os,signal,subprocess,sys,time,statistics
from pathlib import Path
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,v):
 tmp=p.with_suffix(".tmp");tmp.write_text(json.dumps(v,indent=2,allow_nan=False));os.replace(tmp,p)
def main():
 p=argparse.ArgumentParser()
 for name in ("root","baseline-study","tensor-study","r1-trainer","r2-tools","plan-parameters","output-dir","lock-file"):
  p.add_argument("--"+name,type=Path,required=True)
 p.add_argument("--hard-deadline-epoch",type=float,required=True)
 a=p.parse_args();start=time.time();deadline=a.hard_deadline_epoch
 a.output_dir=a.output_dir.resolve();root=a.root.resolve()
 rel=a.output_dir.relative_to(root);assert rel.parts[0].startswith("sac-alpha-pilot-") and len(rel.parts)>=2
 assert not a.output_dir.exists()
 for study in (a.baseline_study,a.tensor_study):assert not a.output_dir.is_relative_to(study.resolve())
 # Authorize only the already-reviewed N07/T02 source difference.
 files=lambda r:{str(f.relative_to(r)):f for f in r.rglob("*.py") if "__pycache__" not in f.parts}
 b=files(a.baseline_study);m=files(a.tensor_study);assert b.keys()==m.keys()
 changes=[k for k in b if digest(b[k])!=digest(m[k])]
 assert set(changes)=={"networks_learning/entropy_temperature/temperature.py","training_validation/training_loop/runner.py"},changes
 rk="training_validation/training_loop/runner.py"
 expected=b[rk].read_text().replace("Temperature, current_alpha,","Temperature, current_alpha, current_alpha_tensor,").replace("current_alpha(self.temperature)","current_alpha_tensor(self.temperature)")
 assert expected==m[rk].read_text(),"unexpected runner modifications"
 tk="networks_learning/entropy_temperature/temperature.py"
 old_tree=ast.parse(b[tk].read_text());new_tree=ast.parse(m[tk].read_text())
 helpers=[node for node in new_tree.body if isinstance(node,ast.FunctionDef) and node.name=="current_alpha_tensor"]
 assert len(helpers)==1
 wanted=ast.parse('def current_alpha_tensor(temperature: Temperature) -> torch.Tensor:\n    return temperature.log_alpha.detach().exp()').body[0]
 def strip_docs(tree):
  for node in ast.walk(tree):
   if isinstance(node,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):
    node.body.pop(0)
  return tree
 assert ast.dump(strip_docs(copy.deepcopy(helpers[0])))==ast.dump(wanted)
 new_tree.body.remove(helpers[0])
 assert ast.dump(strip_docs(old_tree))==ast.dump(strip_docs(new_tree)),"unexpected temperature modifications"
 a.output_dir.mkdir(parents=True)
 report=dict(status="active",deadline=deadline,requested_groups=20,requested_pairs=10,groups_attempted=0,
  groups_complete=0,pairs_complete=0,policy_evaluation_performed=False,pairs=[],
  failure_policy="Continue after isolated arm failure or timeout. Stop globally on source change, disk below 10GiB, signal or deadline. Missing first-arm initialization blocks only its second arm; never count it complete.",
  limitations="Alternating order across ten paired seeds reduces but cannot eliminate thermal/time/order effects. Training logs are not frozen-policy evaluation.")
 source_hashes={str(path):digest(path) for path in list(b.values())+list(m.values())}
 save(a.output_dir/"source_hashes.json",source_hashes)
 def update():
  arms=[v for pair in report["pairs"] for v in pair["arms"].values()]
  report["groups_attempted"]=sum(v.get("attempted",False) for v in arms)
  report["groups_complete"]=sum(v.get("complete",False) for v in arms)
  report["pairs_complete"]=sum(v.get("complete",False) for v in report["pairs"])
  report["elapsed_seconds"]=time.time()-start
  save(a.output_dir/"queue_summary.json",report)
 update()
 env=os.environ.copy()
 for key in ("LD_LIBRARY_PATH","LD_PRELOAD"):env.pop(key,None)
 env.update(PYTHONPATH=str(a.r2_tools)+":"+str(root/"tools"),
  VK_DRIVER_FILES=str(root/"runs/nvidia-egl-test.json"),VK_ICD_FILENAMES=str(root/"runs/nvidia-egl-test.json"),
  VK_LOADER_LAYERS_DISABLE="~implicit~",OMNI_KIT_ACCEPT_EULA="YES")
 script=Path(__file__).with_name("run_alpha_performance_arm.py")
 proc=None
 def stop(signum,frame):
  if proc is not None and proc.poll() is None:
   os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  raise InterruptedError("supervisor signal "+str(signum))
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:
  for seed in range(10):
   order=["baseline","tensor"] if seed%2==0 else ["tensor","baseline"]
   pair=dict(seed=seed,order=order,arms={},complete=False,evaluation_seed=101+seed%3)
   report["pairs"].append(pair);pairdir=a.output_dir/("pair-%02d"%seed);pairdir.mkdir()
   for position,variant in enumerate(order,1):
    assert time.time()+150<=deadline,"insufficient remaining budget for next arm"
    assert shutil.disk_usage(a.output_dir).free>=10*1024**3,"disk below 10GiB"
    assert all(digest(Path(path))==value for path,value in source_hashes.items()),"source changed"
    out=pairdir/variant;study=a.baseline_study if variant=="baseline" else a.tensor_study
    record=dict(variant=variant,position=position,attempted=False,complete=False)
    pair["arms"][variant]=record
    initial=pairdir/order[0]/"initial_fingerprints.json"
    if position==2 and not initial.is_file():
     record["error"]="first arm has no initialization fingerprint; second arm blocked";update();continue
    cmd=[str(root/".venv/bin/python"),str(script),"--root",str(root),"--study-root",str(study),
     "--r1-trainer",str(a.r1_trainer),"--r2-tools",str(a.r2_tools),"--plan-parameters",str(a.plan_parameters),
     "--output-dir",str(out),"--lock-file",str(a.lock_file),"--variant",variant,"--num-envs","128",
     "--seed",str(seed),"--pair-position",str(position),
     "--max-seconds","140","--hard-deadline-epoch",str(min(time.time()+150,deadline)),"--headless","--device","cuda:0"]
    if position==2:cmd+=["--expected-initial-fingerprints",str(initial)]
    record.update(command=cmd,started_epoch=time.time());update()
    try:
     with (pairdir/(variant+".log")).open("w") as log:
      proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
      record["attempted"]=True;update()
      try:proc.wait(timeout=150)
      except subprocess.TimeoutExpired:
       os.killpg(proc.pid,signal.SIGKILL);proc.wait()
       raise TimeoutError(variant+" exceeded 150 seconds")
     summary=read(out/"summary.json");record.update(exit_code=proc.returncode,summary=summary)
     assert summary["status"]=="completed" and summary["counters"]["iterations"]==64
     rows=[json.loads(line) for line in (out/"timings.jsonl").read_text().splitlines()]
     assert len(rows)==64
     record["timing"]={key:{"sum":sum(row[key] for row in rows),"median":statistics.median(row[key] for row in rows)} for key in ("collect_s","learn_s","auxiliary_s","iteration_wall_s","source_hash_s","diagnostics_s")}
     record["complete"]=True
    except InterruptedError:raise
    except Exception as exc:
     record["error"]=repr(exc)
     if (out/"summary.json").is_file():record["summary"]=read(out/"summary.json")
    record["process_wall_s"]=time.time()-record["started_epoch"]
    save(pairdir/"pair_summary.json",pair);update()
   if all(pair["arms"].get(v,{}).get("complete",False) for v in order):
    bs=pair["arms"]["baseline"];ts=pair["arms"]["tensor"]
    match=bs["summary"]["initial_fingerprints"]==ts["summary"]["initial_fingerprints"]
    pair["initial_fingerprints_match"]=match
    if match:
     pair.update(complete=True,final_fingerprints_equal=bs["summary"]["final_fingerprints"]==ts["summary"]["final_fingerprints"],
      learn_wall_difference_s=ts["timing"]["learn_s"]["sum"]-bs["timing"]["learn_s"]["sum"],
      iteration_wall_difference_s=ts["timing"]["iteration_wall_s"]["sum"]-bs["timing"]["iteration_wall_s"]["sum"],
      process_wall_difference_s=ts["process_wall_s"]-bs["process_wall_s"])
   save(pairdir/"pair_summary.json",pair);update()
  report["status"]="completed" if report["groups_complete"]==20 and report["pairs_complete"]==10 else "incomplete"
 except BaseException as exc:report.update(status="stopped",error=repr(exc))
 finally:update()
 return 0 if report["status"]=="completed" else 1
if __name__=="__main__":sys.exit(main())

