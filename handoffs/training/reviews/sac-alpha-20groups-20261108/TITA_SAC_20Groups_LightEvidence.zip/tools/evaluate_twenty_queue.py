import os,sys,json,time,subprocess,hashlib,signal,fcntl
from pathlib import Path
ROOT=Path('/root/rivermind-data/tita-check')
RUN=ROOT/'sac-alpha-pilot-twenty-20261108/run-001'
DEADLINE=1794143100
def read(p):return json.loads(p.read_text())
def save(p,v):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2,allow_nan=False));os.replace(t,p)
out=RUN/'evaluation';out.mkdir(exist_ok=False)
report={'status':'waiting_for_training','requested_groups':20,'groups_attempted':0,'groups_complete':0,'pairs':[],'protocol':'F01 D standard600; eval seed101+training_seed%3; frozen; no concurrent training','deadline':DEADLINE}
def update():
 arms=[v for pair in report['pairs'] for v in pair['arms'].values()]
 report['groups_attempted']=sum(v.get('attempted',False) for v in arms)
 report['groups_complete']=sum(v.get('complete',False) for v in arms)
 report['updated_epoch']=time.time();save(out/'SUMMARY.json',report)
update();proc=None
def stop(signum,frame):
 if proc is not None and proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 raise InterruptedError('evaluation supervisor signal '+str(signum))
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
try:
 while True:
  assert time.time()<DEADLINE-100,'evaluation deadline before training completion'
  f=RUN/'queue_summary.json'
  if f.exists():
   q=read(f)
   if q['status']!='active':break
  time.sleep(5)
 report['training_queue_status']=q['status']
 hashes=read(RUN/'source_hashes.json')
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in hashes.items()),'source changed after training'
 script=ROOT/'sac-alpha-twenty-tools/evaluate_twenty_source.py'
 report['script_sha256']=hashlib.sha256(script.read_bytes()).hexdigest()
 env=os.environ.copy()
 for key in ('LD_LIBRARY_PATH','LD_PRELOAD'):env.pop(key,None)
 env.update(PYTHONPATH=str(ROOT/'sac-r2-20261108/tools')+':'+str(ROOT/'tools'),PYTHONDONTWRITEBYTECODE='1',VK_DRIVER_FILES=str(ROOT/'runs/nvidia-egl-test.json'),VK_ICD_FILENAMES=str(ROOT/'runs/nvidia-egl-test.json'),VK_LOADER_LAYERS_DISABLE='~implicit~',OMNI_KIT_ACCEPT_EULA='YES')
 for pair in q['pairs']:
  seed=pair['seed'];evseed=101+seed%3;pd=RUN/('pair-%02d'%seed);ed=out/('pair-%02d'%seed);ed.mkdir()
  result={'seed':seed,'evaluation_seed':evseed,'order':pair['order'],'arms':{}}
  report['pairs'].append(result)
  for variant in pair['order']:
   record={'attempted':False,'complete':False};result['arms'][variant]=record
   training=pair['arms'].get(variant,{})
   if not training.get('complete',False):
    record['error']='training arm incomplete; no valid final checkpoint';update();continue
   assert time.time()<DEADLINE-100,'insufficient remaining evaluation budget'
   ck=pd/variant/'model_only.pt';assert hashlib.sha256(ck.read_bytes()).hexdigest()==training['summary']['final_model']['sha256']
   study=ROOT/('sac-r2-20261108/study' if variant=='baseline' else 'sac-paper-branch-20261108')
   cmd=[str(ROOT/'.venv/bin/python'),str(script),'--root',str(ROOT),'--study-root',str(study),'--checkpoint',str(ck),'--output_dir',str(ed/variant),'--eval_seed',str(evseed),'--condition','standard','--execution','D','--factor','F01','--policy-noise','on','--zero-reset-wrench','--disable-interval-push','--headless','--device','cuda:0']
   record.update(command=cmd,started_epoch=time.time());report.update(status='running',current_seed=seed,current_variant=variant);update()
   try:
    with (ed/(variant+'.log')).open('w') as log:
     proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['attempted']=True;update()
     try:proc.wait(timeout=90)
     except subprocess.TimeoutExpired:
      os.killpg(proc.pid,signal.SIGKILL);proc.wait();raise
    s=read(ed/variant/'summary.json');record.update(summary=s,exit_code=proc.returncode)
    assert s['status']=='passed',s
    assert s['frozen_state_unchanged'] and s['checkpoint_unchanged'] and s['normalizers_unchanged']
    cfg=read(ed/variant/'configuration.json');assert cfg['training_seed']==seed
    record['complete']=True
   except InterruptedError:raise
   except Exception as exc:record['error']=repr(exc)
   record['process_wall_s']=time.time()-record['started_epoch'];update()
  if all(result['arms'].get(v,{}).get('complete',False) for v in ('baseline','tensor')):
   b=result['arms']['baseline']['summary'];m=result['arms']['tensor']['summary']
   result.update(initial_states_equal=b['initial_state']==m['initial_state'],step_logs_identical=(ed/'baseline/steps.jsonl').read_bytes()==(ed/'tensor/steps.jsonl').read_bytes())
  save(ed/'pair_summary.json',result);update()
 report['status']='completed' if report['groups_complete']==20 else 'incomplete'
except BaseException as exc:
 if proc is not None and proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 report.update(status='stopped',error=repr(exc))
finally:update()
