#!/usr/bin/env python3
"""SAC-R1 有界执行入口：复用 study Trainer，绝不恢复 PPO 或自动增加续训轮数。"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time
import traceback
from dataclasses import asdict, replace

PLAN_ID = 'SAC-R1-20261107'
MILESTONES = (262144, 524288, 1048576)


def write_json(path, value):
    """同目录临时文件、fsync 与原子替换；拒绝非有限 JSON。"""
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False, default=str)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def install_paths(root):
    for sub in ('environment_control/robot_environment', 'environment_control/episode_lifecycle',
                'environment_control/observation_interface', 'environment_control/action_contract',
                'training_validation/configuration', 'training_validation/training_loop',
                'training_validation/checkpoints'):
        sys.path.insert(0, str(root / sub))


def fingerprint(value):
    """内容指纹跨设备一致，包含张量 dtype/shape 与优化器空状态/超参数。"""
    import torch
    h = hashlib.sha256()
    def add(x):
        if isinstance(x, torch.Tensor):
            x = x.detach().cpu().contiguous()
            h.update(str((str(x.dtype), list(x.shape))).encode())
            h.update(x.numpy().tobytes())
        elif isinstance(x, dict):
            for k in sorted(x, key=str):
                h.update(str(k).encode()); add(x[k])
        elif isinstance(x, (list, tuple)):
            for y in x: add(y)
        else:
            h.update(repr(x).encode())
    add(value)
    return h.hexdigest()


def check_finite(trainer):
    """每轮检查参数/缓冲及优化器，单设备汇总后同步，失败不进入下一轮。"""
    import torch
    checks = {}
    def visit(x):
        if isinstance(x, torch.Tensor) and x.is_floating_point():
            checks.setdefault(x.device, []).append(torch.isfinite(x).all())
        elif isinstance(x, dict):
            for y in x.values(): visit(y)
        elif isinstance(x, (list, tuple)):
            for y in x: visit(y)
    for name in ('encoder', 'projector', 'actor', 'critics', 'targets', 'temperature'):
        visit(getattr(trainer, name).state_dict())
    for opt in trainer.optimizers.values(): visit(opt.state_dict())
    visit(trainer.normalizers.export_statistics())
    if any(not bool(torch.stack(values).all()) for values in checks.values()):
        raise FloatingPointError('Nonfinite network, optimizer or normalizer state')


def validated_save(trainer, output, name, replay=False):
    """原子保存并安全读回结构/精确计数，记录 SHA；model_only 不含池但含推理依赖。"""
    import torch
    from checkpoint import save_checkpoint, CHECKPOINT_FORMAT
    path = save_checkpoint(trainer, output / name, include_replay=replay)
    state = torch.load(path, map_location='cpu', weights_only=True)
    assert state['format'] == CHECKPOINT_FORMAT
    assert state['counters'] == asdict(trainer.counters)
    assert (state['replay'] is not None) == replay
    digest = sha256(path)
    return dict(path=str(path.resolve()), sha256=digest, bytes=path.stat().st_size,
                transitions=trainer.counters.transitions, counters=asdict(trainer.counters),
                includes_replay=replay, readback_verified=True)


def make_trainer(args):
    """构造原 TRAIN 派生 SAC 任务，仅改变计划规定的站立比例与采集/学习规模。"""
    from assets import WHEEL_JOINTS, parse_urdf_joints, soft_joint_limits, verify_urdf, wheel_half_track, wheel_radius
    from baseline_source import load_baseline_action_contract
    from contract import ControlType, validate_action_contract
    from isaac_env import TitaSacHooks, make_env, make_sac_cfg, read_runtime_metadata, sac_config_differences, urdf_path_from_cfg
    from lifecycle import EpisodeLifecycle
    from metadata import LEG_SOFT_LIMIT_FACTOR, baseline_command_ranges, baseline_timing, compare_with_baseline, fill_isaac_run_config, required_wheel_speed, wheel_speed_ranges
    from config import export_run_configuration
    from runner import Trainer
    contract = load_baseline_action_contract()
    validate_action_contract(contract)
    cfg = make_sac_cfg('isaac_flat', 16, 0, args.device or 'cuda:0')
    cfg.commands.base_velocity.rel_standing_envs = .02 if args.arm == 'S0' else .20
    urdf = urdf_path_from_cfg(cfg)
    asset_check = verify_urdf(urdf)
    joints = parse_urdf_joints(urdf)
    legs = [e.joint_name for e in contract.entries if e.control_type is ControlType.POSITION]
    urdf_soft = soft_joint_limits(joints, legs, LEG_SOFT_LIMIT_FACTOR)
    default_pose = {e.joint_name: e.default_target for e in contract.entries if e.control_type is ControlType.POSITION}
    half_track, radius = wheel_half_track(joints, default_pose), wheel_radius(urdf, WHEEL_JOINTS[0])
    timing, commands = baseline_timing(), baseline_command_ranges()
    required = required_wheel_speed(commands, half_track, radius)
    env = make_env('isaac_flat', cfg)
    args._env = env  # 之后任何异常都由 finally 关闭。
    runtime = read_runtime_metadata(env, 'isaac_flat')
    q_dim = compare_with_baseline(runtime, contract, timing, commands, urdf_soft)
    if q_dim != 54: raise ValueError(f'Flat Q dimension {q_dim}, expected 54')
    ranges = wheel_speed_ranges(20., required, model_limit=min(runtime.joint_vel_limits[n] for n in WHEEL_JOINTS))
    config = fill_isaac_run_config(runtime, contract, q_dim, ranges, required, seed=0,
                                  steps_per_iteration=8, capacity_per_env=4096, debug_sizes=False)
    config = replace(config, name=PLAN_ID, device=args.learner_device,
                     collection=replace(config.collection, warmup_iterations=128),
                     algorithm=replace(config.algorithm, batch_size=256, critic_updates_per_iteration=16,
                                       auxiliary_updates_per_iteration=16, auxiliary_batch_size=256),
                     sources=config.sources | {'device': PLAN_ID + ': explicitly selected, independently validated learner',
                                               'collection.warmup_iterations': PLAN_ID,
                                               'algorithm.critic_updates_per_iteration': PLAN_ID,
                                               'algorithm.auxiliary_updates_per_iteration': PLAN_ID})
    export_run_configuration(config, args.output_dir / 'run_config.json')
    # Isaac 的完整生效任务配置也保存；不是只保留训练器参数。
    from isaaclab.utils.io import dump_yaml
    dump_yaml(str(args.output_dir / 'environment_config.yaml'), cfg)
    write_json(args.output_dir / 'metadata.json', dict(plan_id=PLAN_ID, arm=args.arm,
        rel_standing_envs=cfg.commands.base_velocity.rel_standing_envs,
        runtime=asdict(runtime), asset_check=asset_check, sac_vs_ppo=sac_config_differences('isaac_flat'),
        learner_device=config.device, replay_device='cpu', seed=0, warmup_in_total=True,
        initial_episode_length_randomized=False, fixed_evaluation_commands_in_training=False))
    hooks = TitaSacHooks(env, False)
    trainer = Trainer(config, EpisodeLifecycle(hooks, 'isaac_flat', q_dim), contract)
    return trainer, hooks


def train(args):
    import torch
    from checkpoint import MODULE_NAMES
    trainer, hooks = make_trainer(args)
    args._trainer = trainer
    initial = dict(networks=fingerprint({n: getattr(trainer, n).state_dict() for n in MODULE_NAMES}),
                   optimizers=fingerprint({n: o.state_dict() for n, o in trainer.optimizers.items()}),
                   normalizers=fingerprint(trainer.normalizers.export_statistics()),
                   empty_replay=trainer.buffer.size == 0)
    write_json(args.output_dir / 'initial_fingerprints.json', initial)
    if args.expected_initial_fingerprints is not None:
        expected = json.loads(args.expected_initial_fingerprints.read_text())
        for key in ('networks','optimizers','normalizers','empty_replay'):
            if initial[key] != expected[key]:
                raise ValueError(f'Fresh arm initial fingerprint mismatch: {key}')
    # 预算从首次采集前开始，探针、记录、检查与保存全部计入；预留最终保存时间。
    start = time.monotonic()
    deadline = min(start + args.max_seconds, start + args.deadline_epoch - time.time())
    save_reserve = 90.0
    summary = dict(plan_id=PLAN_ID, arm=args.arm, status='active', learner_device=args.learner_device,
                   initial_fingerprints=initial, milestones=[], final_model=None, transitions=0,
                   max_seconds=args.max_seconds, max_iterations=args.max_iterations,
                   core_start_epoch=time.time(), core_elapsed_seconds=0., throughput_50=None)
    args._summary = summary
    write_json(args.output_dir / 'summary.json', summary)
    columns = ['iteration','transitions','env_steps','critic_updates','actor_updates','alpha_updates',
               'target_updates','auxiliary_updates','auxiliary_skipped','auxiliary_attempts',
               'elapsed_seconds','iteration_seconds','reward_mean','terminated','time_out','critic_loss',
               'actor_loss','alpha','q1_mean','q2_mean','target_mean','target_abs_max','disk_free_bytes']
    learning_start = None
    with (args.output_dir / 'iterations.csv').open('w', newline='') as csvfile, (args.output_dir / 'iterations.jsonl').open('w') as detail:
        writer = csv.DictWriter(csvfile, fieldnames=columns); writer.writeheader()
        while trainer.counters.iterations < args.max_iterations:
            if args._stop or time.monotonic() >= deadline - save_reserve:
                break
            before = time.monotonic()
            if trainer.counters.iterations == 128:
                learning_start = before
                if args.validate_device:
                    from device_validation import validate_device_parity
                    parity = validate_device_parity(trainer, source='real_isaac_warmup_replay')
                    write_json(args.output_dir / 'real_batch_device_validation.json', parity)
            log = trainer.train(1)[0]
            check_finite(trainer)
            elapsed = time.monotonic() - start
            row = {k: v for k,v in asdict(trainer.counters).items() if k in columns}
            row.update(iteration=trainer.counters.iterations, elapsed_seconds=elapsed,
                       iteration_seconds=time.monotonic()-before,
                       auxiliary_attempts=trainer.counters.auxiliary_updates+trainer.counters.auxiliary_skipped,
                       disk_free_bytes=shutil.disk_usage(args.output_dir).free)
            row.update(log['collect'])
            row.update({k:v for k,v in log.get('learn',{}).items() if k in columns})
            writer.writerow(row); csvfile.flush()
            from runner import features_from_history
            with torch.no_grad():
                features = features_from_history(trainer.encoder, trainer.normalizers,
                                                  trainer.observation.policy_history.to(trainer.device))
                mean, log_std = trainer.actor.distribution_parameters(features)
                log['exploration'] = dict(internal_std_mean=float(log_std.exp().mean()),
                    internal_std_min=float(log_std.exp().min()),internal_std_max=float(log_std.exp().max()),
                    mean_abs_tanh_center=float(mean.tanh().abs().mean()))
            log['elapsed_seconds'] = elapsed
            log['episode_reward_components'] = {k: float(v) for k,v in hooks.last_episode_log.items()
                                                if isinstance(v,(int,float)) or (isinstance(v,torch.Tensor) and v.numel()==1)}
            detail.write(json.dumps(log, allow_nan=False)+'\n'); detail.flush()
            if trainer.counters.iterations == 178:
                seconds = time.monotonic() - learning_start
                summary['throughput_50'] = dict(learning_rounds=50, seconds=seconds,
                    transitions=6400, estimated_full_core_seconds=(learning_start-start)+seconds/50*(8192-128),
                    counted_in_core_budget=True)
            if trainer.counters.transitions in MILESTONES:
                summary['milestones'].append(validated_save(trainer,args.output_dir,
                    f'model_{trainer.counters.transitions:07d}.pt'))
            summary.update(counters=asdict(trainer.counters),transitions=trainer.counters.transitions,
                           core_elapsed_seconds=time.monotonic()-start)
            write_json(args.output_dir / 'summary.json', summary)
        summary['final_model'] = validated_save(trainer,args.output_dir,'model_final.pt')
        # 限量恢复文件：只保留最终一个完整经验池；里程碑不反复复制大池。
        if time.monotonic() < deadline-30:
            summary['resume_checkpoint'] = validated_save(trainer,args.output_dir,'resume_final.pt',replay=True)
        else:
            summary['resume_checkpoint'] = None
            summary['resume_omitted_reason'] = 'insufficient remaining core budget'
    summary.update(status='completed' if trainer.counters.iterations == args.max_iterations else 'budget_exhausted',
                   termination_reason='signal' if args._stop else ('max_iterations' if trainer.counters.iterations==args.max_iterations else 'core_deadline'),
                   counters=asdict(trainer.counters),transitions=trainer.counters.transitions,
                   core_elapsed_seconds=time.monotonic()-start,
                   deadline_overrun_seconds=max(0.,time.monotonic()-deadline),
                   auxiliary_attempts=trainer.counters.auxiliary_updates+trainer.counters.auxiliary_skipped,
                   torch_cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated() if torch.cuda.is_available() else 0,
                   torch_cuda_peak_reserved_bytes=torch.cuda.max_memory_reserved() if torch.cuda.is_available() else 0,
                   gpu_memory_scope='Torch peaks exclude PhysX, renderer and other processes')
    write_json(args.output_dir / 'summary.json', summary)
    write_json(args.output_dir / 'completed.json',summary)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-root',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--arm',choices=['S0','S1'],required=True)
    parser.add_argument('--expected-initial-fingerprints',type=Path)
    parser.add_argument('--learner-device',choices=['cpu','cuda:0'],required=True)
    parser.add_argument('--max-seconds',type=float,default=7200)
    parser.add_argument('--deadline-epoch',type=float,required=True)
    parser.add_argument('--max-iterations',type=int,default=8192)
    parser.add_argument('--validate-device',action='store_true',help='Compare fixed real warmup batch CPU/CUDA before learning')
    # 与服务器已验证入口一致：先加载依赖，避免 Kit 扩展导入顺序冲突。
    import tensordict, h5py  # noqa: F401
    from isaaclab.app import AppLauncher
    AppLauncher.add_app_launcher_args(parser)
    args=parser.parse_args()
    args.study_root = args.study_root.resolve()
    # 布局为 <数据根>/sac-r1-20261107/study；缓存仍落在既有数据盘根。
    args.root = args.study_root.parents[1]
    if not (0<args.max_seconds<=7200 and 129<=args.max_iterations<=8192):
        parser.error('Require max-seconds (0,7200], max-iterations [129,8192] including 128 warmup')
    if args.arm == 'S1' and args.expected_initial_fingerprints is None:
        parser.error('S1 requires --expected-initial-fingerprints from S0')
    args.output_dir.mkdir(parents=True,exist_ok=True)
    if any(p.name not in ('stdout.log','stderr.log') for p in args.output_dir.iterdir()):
        parser.error('Output directory must be new or contain only supervisor stdout.log/stderr.log')
    args._stop=False; args._env=None
    def stop(signum, frame): args._stop=True
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    install_paths(args.study_root)
    app=None; exit_code=0
    try:
        if time.time()>=args.deadline_epoch: raise TimeoutError('Training deadline already passed')
        from linux_common import prepare_args
        args = prepare_args(args)  # 既有数据盘缓存、--allow-root 与 fsWatcherEnabled=false。
        app=AppLauncher(args).app
        import torch
        torch.set_num_threads(4)
        torch.backends.cuda.matmul.allow_tf32=False
        torch.backends.cudnn.allow_tf32=False
        train(args)
    except BaseException as exc:
        exit_code=1
        failure=dict(plan_id=PLAN_ID,arm=args.arm,status='failed',error_type=type(exc).__name__,
                     error=str(exc),traceback=traceback.format_exc(),epoch=time.time(),
                     last_progress=getattr(args,'_summary',None),stop_following_training=True,
                     counters=asdict(args._trainer.counters) if hasattr(args,'_trainer') else None)
        # Isaac close 可能退出进程；失败标志必须在 close 之前持久化。
        write_json(args.output_dir/'failed.json',failure)
        write_json(args.output_dir/'summary.json',failure)
        traceback.print_exc()
    finally:
        if args._env is not None:
            try: args._env.close()
            except BaseException as exc:
                exit_code=1
                write_json(args.output_dir/'failed.json',dict(status='failed',phase='env_close',
                    error=str(exc),stop_following_training=True))
                traceback.print_exc()
        if app is not None: app.close()
    return exit_code

if __name__=='__main__':
    sys.exit(main())
