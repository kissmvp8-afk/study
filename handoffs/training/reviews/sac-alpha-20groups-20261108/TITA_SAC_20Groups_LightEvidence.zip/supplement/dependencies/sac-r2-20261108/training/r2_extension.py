"""SAC-R2 external environment reward and pre-reset diagnostics. No learner loss changes."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import torch
from isaaclab.managers import RewardTermCfg, RewardManager
from isaac_env import TitaSacHooks

PLAN = "SAC-R2-20261108"
WEIGHTS = {"R20": 0.0, "R21": -2.0}

def parking_value(command, linear, angular):
    mask = (torch.linalg.vector_norm(command[:, :2], dim=1) < .05) & (command[:, 2].abs() < .05)
    return mask * (linear[:, 0].square() + linear[:, 1].square() + .25 * angular[:, 2].square())

def parking_body_velocity(env):
    robot = env.scene["robot"]
    return parking_value(env.command_manager.get_command("base_velocity"),
                         robot.data.root_lin_vel_b, robot.data.root_ang_vel_b)

def configure(cfg, arm):
    cfg.commands.base_velocity.rel_standing_envs = .20
    cfg.observations.policy.enable_corruption = True
    cfg.events.base_external_force_torque.params["force_range"] = (0., 0.)
    cfg.events.base_external_force_torque.params["torque_range"] = (0., 0.)
    cfg.events.push_robot = None
    assert cfg.rewards.stand_still.weight == 0
    assert not hasattr(cfg.rewards, "parking_body_velocity"), "Refuse to overwrite a reward"
    cfg.rewards.parking_body_velocity = RewardTermCfg(func=parking_body_velocity, weight=WEIGHTS[arm])
    return cfg

def contract_tests(env):
    # No physics stepping, RNG consumption, model update or live-manager mutation.
    dev = env.device
    c = torch.tensor([[0,0,0],[.3,0,0],[0,0,.1],[0,0,0],[.04,.04,0],
                      [.05,0,0],[0,0,.05],[0,0,-.1]], dtype=torch.float32, device=dev)
    v = torch.ones((8,3), device=dev); w = torch.ones_like(v)
    v[3] = 0; w[3] = 0
    raw = parking_value(c,v,w)
    torch.testing.assert_close(raw, torch.tensor([2.25,0,0,0,0,0,0,0],device=dev))
    test_raw = torch.zeros(env.num_envs, device=dev); test_raw[0] = 2.25
    def known_value(_env):
        return test_raw
    results = {}
    for weight in (0., -2.):
        manager = RewardManager({"parking_body_velocity": RewardTermCfg(func=known_value,weight=weight)}, env)
        actual = manager.compute(dt=.02).clone()
        torch.testing.assert_close(actual, test_raw * weight * .02)
        results[str(weight)] = actual.tolist()
    assert results["-2.0"][0] < 0 and results["0.0"][0] == 0
    return {"passed":True, "boundary":"strict < .05 for XY norm and abs yaw",
            "synthetic_manager_reward":results, "dt":.02, "angular_scale":.25}

def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def protect_sources(args):
    # Read-only source checks; caller also archives the complete tree/diff.
    files = sorted(args.study_root.rglob("*.py"))
    files += [Path(__file__).resolve(), Path(args.entry_script).resolve()]
    args._source_hashes = {str(p.resolve()): _sha(p) for p in files}
    return args._source_hashes

def verify_sources(args):
    for p, expected in args._source_hashes.items():
        if _sha(p) != expected:
            raise RuntimeError("Source hash changed: " + p)

def validate_run_config(config, args):
    baseline = json.loads(args.plan_parameters.read_text())["phase_b"]["common_base_config"]
    from dataclasses import asdict
    actual = asdict(config)
    for key in ("seed","mode","task","algorithm","network","collection","environment"):
        # Normalize tuple/list representations only, never values.
        a = json.loads(json.dumps(actual[key]))
        if a != baseline[key]:
            raise RuntimeError("R1 configuration changed outside plan: " + key)
    assert actual["name"] == PLAN and actual["device"] == "cuda:0"

def install_entropy(trainer):
    # Capture the log_prob already used for alpha; no extra policy sampling or RNG changes.
    import runner
    original = runner.update_temperature
    samples = []
    def observed(*args, **kwargs):
        log_prob = args[2]
        samples.append(float(-log_prob.detach().mean()))
        return original(*args, **kwargs)
    runner.update_temperature = observed
    trainer._r2_entropy = samples

def entropy_report(trainer):
    values = trainer._r2_entropy
    target = float(trainer.target_entropy.action_coordinate)
    out = {"coordinate":"physical_action", "target":target,
           "sample_source":"existing alpha-update log_prob, no extra draws",
           "alpha_update_samples":len(values),
           "mean":sum(values)/len(values) if values else None}
    out["mean_minus_target"] = out["mean"] - target if values else None
    values.clear()
    return out

def check_counts(trainer):
    c = trainer.counters
    k = c.iterations
    expected = {"env_steps":8*k, "transitions":128*k,
                "critic_updates":16*max(k-128,0),
                "alpha_updates":16*max(k-128,0),
                "actor_updates":8*max(k-128,0),
                "target_updates":16*max(k-128,0)}
    for key,value in expected.items():
        if getattr(c,key) != value:
            raise RuntimeError("Counter mismatch: " + key)
    if c.auxiliary_updates + c.auxiliary_skipped != 16*max(k-128,0):
        raise RuntimeError("Auxiliary attempts mismatch")

class R2Hooks(TitaSacHooks):
    def __init__(self, env, randomize_initial_episode_length=False):
        super().__init__(env, randomize_initial_episode_length)
        self.samples = []
        self.robot = env.scene["robot"]
        self.wheel_ids = [self.robot.joint_names.index(n)
                          for n in ("joint_left_leg_4","joint_right_leg_4")]
        self.weight = float(env.cfg.rewards.parking_body_velocity.weight)
        assert abs(env.step_dt - .02) < 1e-10
        self.contract_report = contract_tests(env)

    def assert_zero_wrench(self):
        for name in ("_external_force_b","_external_torque_b"):
            value = getattr(self.robot,name)
            if not bool(torch.isfinite(value).all()) or bool(torch.count_nonzero(value)):
                raise RuntimeError("Nonzero/nonfinite external wrench: " + name)

    def reset_all(self):
        result = super().reset_all()
        self.assert_zero_wrench()
        return result

    def reset_envs(self, ids):
        super().reset_envs(ids)
        self.assert_zero_wrench()

    def apply_action_and_simulate(self, action):
        self.assert_zero_wrench()
        super().apply_action_and_simulate(action)
        self.assert_zero_wrench()

    def after_reset(self):
        super().after_reset()
        self.assert_zero_wrench()

    def compute_rewards(self):
        # This is after simulation and terminations, before any environment reset.
        self.assert_zero_wrench()
        result = super().compute_rewards()
        env = self.env
        command = env.command_manager.get_command("base_velocity").detach().clone()
        raw = parking_body_velocity(env).detach()
        weighted = raw * self.weight * env.step_dt
        rm = env.reward_manager
        index = rm.active_terms.index("parking_body_velocity")
        # Isaac Lab 2.3 _step_reward stores weighted/dt-normalized term.
        actual = rm._step_reward[:,index].detach() * env.step_dt
        torch.testing.assert_close(actual, weighted)
        wheels = self.robot.data.joint_vel_target[:,self.wheel_ids].detach()
        for value in (command,raw,weighted,wheels):
            if not bool(torch.isfinite(value).all()):
                raise FloatingPointError("Nonfinite R2 diagnostic")
        if bool((wheels.abs() > 20.0001).any()):
            raise RuntimeError("Physical wheel target outside fixed +/-20 rad/s bounds")
        terms = {n:env.termination_manager.get_term(n).detach().cpu().bool()
                 for n in env.termination_manager.active_terms}
        self.samples.append({"commands":command.cpu(), "raw":raw.cpu(),
                             "weighted":weighted.cpu(), "wheels":wheels.cpu(), "terms":terms})
        return result

    def drain(self):
        samples,self.samples = self.samples,[]
        assert len(samples) == 8, "Exactly eight pre-reset samples per iteration"
        c = torch.cat([s["commands"] for s in samples])
        raw = torch.cat([s["raw"] for s in samples])
        weighted = torch.cat([s["weighted"] for s in samples])
        wheels = torch.cat([s["wheels"] for s in samples])
        mask = (torch.linalg.vector_norm(c[:,:2],dim=1)<.05) & (c[:,2].abs()<.05)
        exact = (c==0).all(dim=1)
        names = list(samples[0]["terms"])
        assert all(list(s["terms"]) == names for s in samples)
        return {"scope":"all 8 control steps x 16 environments, pre-reset",
                "samples":len(c),"parking_weight":self.weight,
                "parking_unweighted_mean":float(raw.mean()),
                "parking_weighted_dt_mean":float(weighted.mean()),
                "parking_weighted_dt_sum":float(weighted.sum()),
                "parking_gate_ratio":float(mask.float().mean()),
                "exact_zero_command_ratio":float(exact.float().mean()),
                "command_distribution":{"min":c.min(0).values.tolist(),
                    "max":c.max(0).values.tolist(),"mean":c.mean(0).tolist(),
                    "std_population":c.std(0,unbiased=False).tolist(),
                    "all_samples":c.tolist()},
                "physical_wheel_target_rad_s":{"abs_max":float(wheels.abs().max()),
                    "at_bound_ratio":float((wheels.abs()>=20.-1e-5).float().mean()),
                    "near_bound_95pct_ratio":float((wheels.abs()>=19.).float().mean()),
                    "denominator":wheels.numel(), "bound":20.},
                "termination_counts":{n:int(torch.cat([s["terms"][n] for s in samples]).sum()) for n in names},
                "termination_note":"Terms may overlap; counts are not mutually exclusive",
                "zero_wrench_checked_each_control_step_and_reset":True,
                "episode_log_scope":"R1 episode_reward_components are latest reset cumulative episode statistics, not step means"}
